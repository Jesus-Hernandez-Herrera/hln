<?php

namespace Openpay\Data;

class OpenpayApiAuthError extends OpenpayApiError
{

}
