<?php

namespace Openpay\Data;

class OpenpayApiConnectionError extends OpenpayApiError
{

}
