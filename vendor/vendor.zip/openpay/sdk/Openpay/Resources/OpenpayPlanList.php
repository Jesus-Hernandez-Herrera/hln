<?php

namespace Openpay\Resources;

use Openpay\Data\OpenpayApiDerivedResource;

class OpenpayPlanList extends OpenpayApiDerivedResource
{
}
