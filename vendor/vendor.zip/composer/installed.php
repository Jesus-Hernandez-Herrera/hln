<?php return array(
    'root' => array(
        'name' => '__root__',
        'pretty_version' => '1.0.0+no-version-set',
        'version' => '1.0.0.0',
        'reference' => null,
        'type' => 'library',
        'install_path' => __DIR__ . '/../../',
        'aliases' => array(),
        'dev' => true,
    ),
    'versions' => array(
        '__root__' => array(
            'pretty_version' => '1.0.0+no-version-set',
            'version' => '1.0.0.0',
            'reference' => null,
            'type' => 'library',
            'install_path' => __DIR__ . '/../../',
            'aliases' => array(),
            'dev_requirement' => false,
        ),
        'openpay/sdk' => array(
            'pretty_version' => '3.1.0',
            'version' => '3.1.0.0',
            'reference' => '65e42b040d1631aec34af54d8cc00a70eac72d50',
            'type' => 'library',
            'install_path' => __DIR__ . '/../openpay/sdk',
            'aliases' => array(),
            'dev_requirement' => false,
        ),
    ),
);
